#!/bin/sh
while true; do
  cd /home/z/my-project
  npx next dev -p 3000 >> /home/z/my-project/dev.log 2>&1
  sleep 2
done

#!/bin/bash
# Fast server check and restart for sandbox environment
# Usage: source /home/z/my-project/ensure-server.sh

ensure_server() {
  if curl -s --connect-timeout 2 --max-time 3 http://localhost:3000 >/dev/null 2>&1; then
    echo "[ensure-server] Next.js already running on port 3000"
    return 0
  fi
  
  echo "[ensure-server] Next.js not running, restarting..."
  
  # Kill any leftover processes
  pkill -f "next dev" 2>/dev/null
  pkill -f "next-server" 2>/dev/null
  sleep 1
  
  # Start fresh
  cd /home/z/my-project
  node /home/z/my-project/node_modules/.bin/next dev -p 3000 >> /home/z/my-project/dev.log 2>&1 &
  
  # Wait for ready (max 60s)
  for i in $(seq 1 20); do
    sleep 3
    if curl -s --connect-timeout 2 --max-time 5 http://localhost:3000 >/dev/null 2>&1; then
      echo "[ensure-server] Server is UP (took ~$((i*3))s)"
      # Pre-compile critical routes
      echo "[ensure-server] Pre-compiling routes..."
      curl -s -o /dev/null http://localhost:3000/ &
      curl -s -o /dev/null http://localhost:3000/api/settings &
      curl -s -o /dev/null http://localhost:3000/api/units &
      curl -s -o /dev/null http://localhost:3000/api/events &
      wait
      echo "[ensure-server] Ready!"
      return 0
    fi
  done
  
  echo "[ensure-server] WARNING: Server failed to start"
  return 1
}

ensure_server
